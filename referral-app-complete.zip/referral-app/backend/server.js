// server.js — Main Express Server
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { v4: uuidv4 } = require("uuid");
const path = require("path");

const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "referral_secret_key_2025_change_in_production";

// ── COMMISSION LEVELS ─────────────────────────────────────────────────────────
const COMMISSION = [0, 500, 250, 125, 62, 31]; // index = depth from referrer

// ── MIDDLEWARE ────────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend/public")));

// ── AUTH MIDDLEWARE ───────────────────────────────────────────────────────────
function auth(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Huhitaji kuingia kwanza" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Tokeni si sahihi au imeisha muda" });
  }
}

function adminOnly(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Ruhusa ya Admin inahitajika" });
  next();
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
const now = () => new Date().toLocaleString("sw-TZ", { dateStyle: "short", timeStyle: "short" });
const getSetting = (key) => db.prepare("SELECT value FROM settings WHERE key=?").get(key)?.value;
const getAdmin = () => db.prepare("SELECT * FROM members WHERE role='admin'").get();

function generateRefCode(name) {
  const prefix = name.slice(0, 3).toUpperCase().replace(/\s/g, "X");
  const suffix = uuidv4().replace(/-/g, "").slice(0, 5).toUpperCase();
  return prefix + suffix;
}

function distributeCommissions(newMemberId, parentId, newMemberName, txnRef) {
  let ancId = parentId;
  let depth = 1;

  while (ancId && depth < COMMISSION.length) {
    const commission = COMMISSION[depth];
    if (!commission) { ancId = db.prepare("SELECT parent_id FROM members WHERE id=?").get(ancId)?.parent_id; depth++; continue; }

    const anc = db.prepare("SELECT * FROM members WHERE id=?").get(ancId);
    if (anc) {
      db.prepare("UPDATE members SET earnings = earnings + ? WHERE id=?").run(commission, ancId);
      db.prepare(`
        INSERT INTO transactions (id, type, from_id, to_id, amount, method, status, note, ref, created_at)
        VALUES (?, 'commission', 'admin', ?, ?, 'internal', 'completed', ?, ?, ?)
      `).run(uuidv4(), ancId, commission, `Commission — ${newMemberName} (Kiwango ${depth})`, txnRef, now());
    }

    ancId = db.prepare("SELECT parent_id FROM members WHERE id=?").get(ancId)?.parent_id;
    depth++;
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// AUTH ROUTES
// ══════════════════════════════════════════════════════════════════════════════

// POST /api/auth/signup
app.post("/api/auth/signup", (req, res) => {
  try {
    const { name, phone, password, method, refCode } = req.body;

    if (!name?.trim()) return res.status(400).json({ error: "Weka jina lako!" });
    if (!phone?.trim()) return res.status(400).json({ error: "Weka namba ya simu!" });
    if (!password || password.length < 4) return res.status(400).json({ error: "Neno la siri liwe na herufi 4+" });

    const cleanPhone = phone.replace(/\D/g, "").replace(/^255/, "0");
    const existing = db.prepare("SELECT id FROM members WHERE replace(replace(phone,'+',''),'255','0') = ?").get(cleanPhone)
      || db.prepare("SELECT id FROM members WHERE phone=?").get(phone.trim());
    if (existing) return res.status(400).json({ error: "Namba hii imeshasajiliwa!" });

    // Find parent
    let parentId = getAdmin()?.id;
    if (refCode?.trim()) {
      const ref = db.prepare("SELECT * FROM members WHERE ref_code=?").get(refCode.trim().toUpperCase());
      if (!ref) return res.status(400).json({ error: "Nambari ya referral si sahihi!" });
      if (!ref.paid) return res.status(400).json({ error: "Mtu aliyekualika hajalipa bado!" });

      const maxRefs = parseInt(getSetting("max_referrals") || "2");
      const kidCount = db.prepare("SELECT COUNT(*) as c FROM members WHERE parent_id=?").get(ref.id).c;
      if (kidCount >= maxRefs) return res.status(400).json({ error: "Mtu aliyekualika amejaa nafasi!" });

      parentId = ref.id;
    }

    const parent = db.prepare("SELECT * FROM members WHERE id=?").get(parentId);
    const newId = uuidv4();
    const refCodeGen = generateRefCode(name.trim());
    const hash = bcrypt.hashSync(password, 10);

    db.prepare(`
      INSERT INTO members (id, name, phone, password, role, paid, parent_id, level, earnings, pay_method, ref_code, joined_at)
      VALUES (?, ?, ?, ?, 'member', 0, ?, ?, 0, ?, ?, ?)
    `).run(newId, name.trim(), phone.trim(), hash, parentId, (parent?.level || 0) + 1, method || "tigo", refCodeGen, now());

    const token = jwt.sign({ id: newId, role: "member" }, JWT_SECRET, { expiresIn: "30d" });
    const member = db.prepare("SELECT id,name,phone,role,paid,level,earnings,pay_method,ref_code,joined_at FROM members WHERE id=?").get(newId);

    res.json({ token, member, message: "Umesajiliwa! Sasa lipa ili kuanzisha akaunti yako." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Hitilafu ya seva: " + err.message });
  }
});

// POST /api/auth/login
app.post("/api/auth/login", (req, res) => {
  try {
    const { phone, password } = req.body;
    const cleanPhone = phone?.trim();
    const member = db.prepare("SELECT * FROM members WHERE phone=?").get(cleanPhone)
      || db.prepare("SELECT * FROM members WHERE phone=?").get("0" + cleanPhone?.replace(/^0+/, ""));

    if (!member) return res.status(400).json({ error: "Namba au neno la siri si sahihi!" });
    if (!bcrypt.compareSync(password, member.password)) return res.status(400).json({ error: "Namba au neno la siri si sahihi!" });

    const token = jwt.sign({ id: member.id, role: member.role }, JWT_SECRET, { expiresIn: "30d" });
    const { password: _, ...safe } = member;
    res.json({ token, member: safe });
  } catch (err) {
    res.status(500).json({ error: "Hitilafu ya seva" });
  }
});

// ══════════════════════════════════════════════════════════════════════════════
// MEMBER ROUTES
// ══════════════════════════════════════════════════════════════════════════════

// GET /api/me — get my profile
app.get("/api/me", auth, (req, res) => {
  const member = db.prepare("SELECT id,name,phone,role,paid,level,earnings,pay_method,ref_code,joined_at,parent_id FROM members WHERE id=?").get(req.user.id);
  if (!member) return res.status(404).json({ error: "Mwanachama hapatikani" });
  const settings = {};
  db.prepare("SELECT key,value FROM settings").all().forEach(r => settings[r.key] = r.value);
  res.json({ member, settings });
});

// POST /api/pay/confirm — member confirms they have paid
app.post("/api/pay/confirm", auth, (req, res) => {
  try {
    const member = db.prepare("SELECT * FROM members WHERE id=?").get(req.user.id);
    if (!member) return res.status(404).json({ error: "Mwanachama hapatikani" });
    if (member.paid) return res.status(400).json({ error: "Umeshalipa!" });

    const entryFee = parseFloat(getSetting("entry_fee") || "2000");
    const txnRef = "TXN" + Date.now();
    const adminId = getAdmin()?.id;

    // Mark paid
    db.prepare("UPDATE members SET paid=1 WHERE id=?").run(member.id);

    // Record payment
    db.prepare(`
      INSERT INTO transactions (id, type, from_id, to_id, amount, method, status, note, ref, created_at)
      VALUES (?, 'payment', ?, ?, ?, ?, 'completed', ?, ?, ?)
    `).run(uuidv4(), member.id, adminId, entryFee, member.pay_method, `Malipo ya kujiandikisha — ${member.name}`, txnRef, now());

    // Distribute commissions
    if (member.parent_id) distributeCommissions(member.id, member.parent_id, member.name, txnRef);

    const updated = db.prepare("SELECT id,name,phone,role,paid,level,earnings,pay_method,ref_code FROM members WHERE id=?").get(member.id);
    res.json({ member: updated, message: "✅ Malipo yamethibitishwa! Akaunti yako imewashwa." });
  } catch (err) {
    res.status(500).json({ error: "Hitilafu ya seva: " + err.message });
  }
});

// POST /api/withdrawal/request
app.post("/api/withdrawal/request", auth, (req, res) => {
  try {
    const { amount, method, phone } = req.body;
    const member = db.prepare("SELECT * FROM members WHERE id=?").get(req.user.id);
    if (!member?.paid) return res.status(400).json({ error: "Lazima ulipie kwanza!" });

    const amt = parseFloat(amount);
    if (!amt || amt < 500) return res.status(400).json({ error: "Kiwango cha chini ni Tsh 500" });
    if (amt > member.earnings) return res.status(400).json({ error: "Mapato yako hayatoshi!" });
    if (!phone?.trim()) return res.status(400).json({ error: "Weka namba ya kupokea!" });

    db.prepare("UPDATE members SET earnings = earnings - ? WHERE id=?").run(amt, member.id);
    db.prepare(`
      INSERT INTO withdrawals (id, member_id, member_name, amount, method, phone, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)
    `).run(uuidv4(), member.id, member.name, amt, method, phone.trim(), now());

    res.json({ message: "✅ Ombi limetumwa! Admin atalipa hivi karibuni." });
  } catch (err) {
    res.status(500).json({ error: "Hitilafu ya seva" });
  }
});

// GET /api/withdrawal/my — get my withdrawal history
app.get("/api/withdrawal/my", auth, (req, res) => {
  const list = db.prepare("SELECT * FROM withdrawals WHERE member_id=? ORDER BY created_at DESC").all(req.user.id);
  res.json({ withdrawals: list });
});

// GET /api/transactions/my
app.get("/api/transactions/my", auth, (req, res) => {
  const list = db.prepare("SELECT * FROM transactions WHERE from_id=? OR to_id=? ORDER BY created_at DESC LIMIT 50").all(req.user.id, req.user.id);
  res.json({ transactions: list });
});

// GET /api/referrals/my — get my referral tree
app.get("/api/referrals/my", auth, (req, res) => {
  const members = db.prepare("SELECT id,name,phone,paid,level,earnings,ref_code,parent_id,joined_at FROM members WHERE parent_id=?").all(req.user.id);
  res.json({ referrals: members });
});

// ══════════════════════════════════════════════════════════════════════════════
// ADMIN ROUTES
// ══════════════════════════════════════════════════════════════════════════════

// GET /api/admin/members
app.get("/api/admin/members", auth, adminOnly, (req, res) => {
  const members = db.prepare("SELECT id,name,phone,role,paid,level,earnings,pay_method,ref_code,parent_id,joined_at FROM members ORDER BY level,joined_at").all();
  res.json({ members });
});

// GET /api/admin/tree — full tree
app.get("/api/admin/tree", auth, adminOnly, (req, res) => {
  const members = db.prepare("SELECT id,name,phone,paid,level,earnings,ref_code,parent_id,pay_method FROM members ORDER BY level").all();
  res.json({ members });
});

// POST /api/admin/member/add — admin adds member manually
app.post("/api/admin/member/add", auth, adminOnly, (req, res) => {
  try {
    const { name, phone, method, parentId } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: "Weka jina!" });
    if (!phone?.trim()) return res.status(400).json({ error: "Weka simu!" });

    const existing = db.prepare("SELECT id FROM members WHERE phone=?").get(phone.trim());
    if (existing) return res.status(400).json({ error: "Namba hii imeshasajiliwa!" });

    const targetParentId = parentId || getAdmin()?.id;
    const parent = db.prepare("SELECT * FROM members WHERE id=?").get(targetParentId);
    if (!parent?.paid) return res.status(400).json({ error: "Mtu mkubwa hajalipa!" });

    const maxRefs = parseInt(getSetting("max_referrals") || "2");
    const kidCount = db.prepare("SELECT COUNT(*) as c FROM members WHERE parent_id=?").get(targetParentId).c;
    if (kidCount >= maxRefs) return res.status(400).json({ error: "Mtu mkubwa amejaa nafasi!" });

    const newId = uuidv4();
    const refCode = generateRefCode(name.trim());
    const defaultPass = phone.trim().slice(-4);
    const hash = bcrypt.hashSync(defaultPass, 10);
    const entryFee = parseFloat(getSetting("entry_fee") || "2000");
    const txnRef = "TXN" + Date.now();

    db.prepare(`
      INSERT INTO members (id, name, phone, password, role, paid, parent_id, level, earnings, pay_method, ref_code, joined_at)
      VALUES (?, ?, ?, ?, 'member', 1, ?, ?, 0, ?, ?, ?)
    `).run(newId, name.trim(), phone.trim(), hash, targetParentId, (parent.level || 0) + 1, method || "tigo", refCode, now());

    db.prepare(`
      INSERT INTO transactions (id, type, from_id, to_id, amount, method, status, note, ref, created_at)
      VALUES (?, 'payment', ?, 'admin', ?, ?, 'completed', ?, ?, ?)
    `).run(uuidv4(), newId, entryFee, method || "tigo", `Malipo ya kujiandikisha — ${name}`, txnRef, now());

    distributeCommissions(newId, targetParentId, name.trim(), txnRef);

    res.json({
      message: `✅ ${name} ameongezwa! Neno la siri: ${defaultPass}`,
      memberId: newId,
    });
  } catch (err) {
    res.status(500).json({ error: "Hitilafu: " + err.message });
  }
});

// GET /api/admin/withdrawals
app.get("/api/admin/withdrawals", auth, adminOnly, (req, res) => {
  const list = db.prepare("SELECT * FROM withdrawals ORDER BY created_at DESC").all();
  res.json({ withdrawals: list });
});

// POST /api/admin/withdrawal/approve
app.post("/api/admin/withdrawal/approve", auth, adminOnly, (req, res) => {
  try {
    const { id } = req.body;
    const wd = db.prepare("SELECT * FROM withdrawals WHERE id=?").get(id);
    if (!wd) return res.status(404).json({ error: "Ombi halipatikani" });
    if (wd.status !== "pending") return res.status(400).json({ error: "Ombi hili limeshafanyiwa kazi" });

    db.prepare("UPDATE withdrawals SET status='completed' WHERE id=?").run(id);
    db.prepare(`
      INSERT INTO transactions (id, type, from_id, to_id, amount, method, status, note, created_at)
      VALUES (?, 'withdrawal', 'admin', ?, ?, ?, 'completed', ?, ?)
    `).run(uuidv4(), wd.member_id, wd.amount, wd.method, `Malipo kwa ${wd.member_name} — ${wd.phone}`, now());

    res.json({ message: `✅ Umelipa ${wd.amount} kwa ${wd.member_name}` });
  } catch (err) {
    res.status(500).json({ error: "Hitilafu ya seva" });
  }
});

// POST /api/admin/withdrawal/reject
app.post("/api/admin/withdrawal/reject", auth, adminOnly, (req, res) => {
  try {
    const { id } = req.body;
    const wd = db.prepare("SELECT * FROM withdrawals WHERE id=?").get(id);
    if (!wd || wd.status !== "pending") return res.status(400).json({ error: "Ombi halipatikani au limeshafanyiwa kazi" });

    db.prepare("UPDATE withdrawals SET status='rejected' WHERE id=?").run(id);
    db.prepare("UPDATE members SET earnings = earnings + ? WHERE id=?").run(wd.amount, wd.member_id);

    res.json({ message: "Ombi limekataliwa. Fedha imerudishwa kwa mwanachama." });
  } catch (err) {
    res.status(500).json({ error: "Hitilafu ya seva" });
  }
});

// GET /api/admin/transactions
app.get("/api/admin/transactions", auth, adminOnly, (req, res) => {
  const list = db.prepare("SELECT * FROM transactions ORDER BY created_at DESC LIMIT 200").all();
  res.json({ transactions: list });
});

// GET /api/admin/stats
app.get("/api/admin/stats", auth, adminOnly, (req, res) => {
  const totalMembers = db.prepare("SELECT COUNT(*) as c FROM members WHERE role!='admin'").get().c;
  const paidMembers = db.prepare("SELECT COUNT(*) as c FROM members WHERE paid=1 AND role!='admin'").get().c;
  const totalRevenue = db.prepare("SELECT SUM(amount) as s FROM transactions WHERE type='payment'").get().s || 0;
  const totalCommissions = db.prepare("SELECT SUM(amount) as s FROM transactions WHERE type='commission'").get().s || 0;
  const pendingWithdrawals = db.prepare("SELECT COUNT(*) as c FROM withdrawals WHERE status='pending'").get().c;
  const pendingAmount = db.prepare("SELECT SUM(amount) as s FROM withdrawals WHERE status='pending'").get().s || 0;

  res.json({
    totalMembers, paidMembers, totalRevenue,
    totalCommissions, pendingWithdrawals, pendingAmount,
    netRevenue: totalRevenue - totalCommissions,
  });
});

// GET /api/admin/settings
app.get("/api/admin/settings", auth, adminOnly, (req, res) => {
  const rows = db.prepare("SELECT * FROM settings").all();
  const settings = {};
  rows.forEach(r => settings[r.key] = r.value);
  res.json({ settings });
});

// POST /api/admin/settings
app.post("/api/admin/settings", auth, adminOnly, (req, res) => {
  const { settings } = req.body;
  const stmt = db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)");
  Object.entries(settings).forEach(([k, v]) => stmt.run(k, String(v)));
  res.json({ message: "✅ Mipangilio imehifadhiwa!" });
});

// GET /api/settings/public — public (no auth needed, for signup page)
app.get("/api/settings/public", (req, res) => {
  const rows = db.prepare("SELECT key,value FROM settings WHERE key IN ('tigo_number','voda_number','selcom_number','entry_fee')").all();
  const settings = {};
  rows.forEach(r => settings[r.key] = r.value);
  res.json({ settings });
});

// ── Catch all → serve frontend ────────────────────────────────────────────────
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/public/index.html"));
});

// ── START ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 Referral Chain Server inaendesha kwenye port ${PORT}`);
  console.log(`🌐 Fungua: http://localhost:${PORT}`);
  console.log(`👑 Admin: Phone=0770527179, Password=admin1234\n`);
});
