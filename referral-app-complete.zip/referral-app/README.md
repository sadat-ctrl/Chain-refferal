# ⛓ REFERRAL CHAIN SYSTEM
## Mfumo Kamili wa Mapato ya Mtandao

---

## 📁 MUUNDO WA FILES

```
referral-app/
├── backend/
│   ├── server.js        ← Seva kuu (Express)
│   ├── db.js            ← Database (SQLite)
│   ├── package.json     ← Dependencies
│   └── referral.db      ← Database (itatengenezwa otomatiki)
└── frontend/
    └── public/
        └── index.html   ← App yote (moja kwa moja)
```

---

## 🚀 JINSI YA KUANZISHA (Local - Majaribio)

### Hatua 1: Sakinisha Node.js
Pakua Node.js kutoka: https://nodejs.org (toleo 18 au zaidi)

### Hatua 2: Sakinisha dependencies
```bash
cd referral-app/backend
npm install
```

### Hatua 3: Anza seva
```bash
node server.js
```

### Hatua 4: Fungua kivinjari
```
http://localhost:3000
```

### Kuingia kama Admin:
- **Simu:** 0770527179
- **Neno la siri:** admin1234

---

## 🌐 JINSI YA KUWEKA KWENYE SERVER (Hosting ya Kweli)

### CHAGUO A: VPS (DigitalOcean, Linode, Hetzner) — BORA ZAIDI

#### 1. Nunua VPS
- DigitalOcean Droplet: $6/mwezi → https://digitalocean.com
- Hetzner: €3.29/mwezi → https://hetzner.com (bei nafuu zaidi)
- Chagua Ubuntu 22.04

#### 2. Ingia kwenye server yako
```bash
ssh root@IP_YAKO
```

#### 3. Sakinisha Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs
```

#### 4. Sakinisha PM2 (kuendesha seva daima)
```bash
npm install -g pm2
```

#### 5. Pakia files zako kwenye server
```bash
# Kwenye kompyuta yako, pakia kwa scp:
scp -r referral-app/ root@IP_YAKO:/var/www/
```

Au tumia FileZilla (GUI) kupakia files.

#### 6. Sakinisha na anza
```bash
cd /var/www/referral-app/backend
npm install
pm2 start server.js --name "referral"
pm2 startup   # Ianze otomatiki baada ya reboot
pm2 save
```

#### 7. Weka Domain (si lazima lakini inapendeza)
```bash
# Sakinisha Nginx
apt install nginx -y

# Tengeneza config
nano /etc/nginx/sites-available/referral
```

Weka hii ndani:
```nginx
server {
    listen 80;
    server_name DOMAIN_YAKO.COM;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
ln -s /etc/nginx/sites-available/referral /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

#### 8. SSL (HTTPS) - Bure!
```bash
apt install certbot python3-certbot-nginx -y
certbot --nginx -d DOMAIN_YAKO.COM
```

---

### CHAGUO B: Railway.app — HARAKA ZAIDI (Bure hadi $5/mwezi)

1. Nenda: https://railway.app
2. Jisajili kwa GitHub
3. Bonyeza "New Project" → "Deploy from GitHub repo"
4. Au tumia Railway CLI:
```bash
npm install -g @railway/cli
railway login
cd referral-app/backend
railway init
railway up
```

---

### CHAGUO C: Render.com — Bure!

1. Nenda: https://render.com
2. Jisajili
3. "New Web Service" → Unganisha GitHub
4. Build Command: `npm install`
5. Start Command: `node server.js`

⚠️ **Kumbuka:** Render ya bure inazimika baada ya dakika 15 bila matumizi.

---

## ⚙️ MIPANGILIO YA MALIPO

Baada ya kuingia kama Admin, nenda **⚙ Admin** na weka:

| Njia | Namba |
|------|-------|
| Tigo Pesa | +255770527179 |
| Vodacom M-Pesa | +255799537179 |
| Selcom | 5525101542364 |

---

## 💰 MFUMO WA COMMISSION

| Kiwango | Commission |
|---------|-----------|
| Mtu uliyemualika moja kwa moja | Tsh 500 |
| Kiwango cha 2 | Tsh 250 |
| Kiwango cha 3 | Tsh 125 |
| Kiwango cha 4 | Tsh 62 |
| Kiwango cha 5 | Tsh 31 |

Kubadilisha commission: hariri `COMM` array katika `backend/server.js` mstari wa 12.

---

## 🔒 USALAMA (Production)

Hariri `backend/server.js` mstari 11:
```javascript
const JWT_SECRET = "WEKA_NENO_GUMU_HAPA_LA_RANDOM_CHARACTERS_2025";
```

Au tumia environment variable:
```bash
JWT_SECRET=neno_gumu_sana node server.js
```

---

## 📱 JINSI MWANACHAMA ANAVYOTUMIA

1. **Fungua link ya referral** (yenye ?ref=CODE yake)
2. **Jisajili** — weka jina, simu, neno la siri
3. **Lipa** — fuata maelekezo ya Tigo/Voda/Selcom
4. **Bonyeza "Nimesha Lipa"** — akaunti inawashwa
5. **Shiriki link yake** — anapata commission kila mtu anayejiunga

---

## 🆘 MATATIZO YA KAWAIDA

**"Cannot find module 'better-sqlite3'"**
```bash
npm install
```

**Port 3000 imeshachukuliwa**
```bash
PORT=4000 node server.js
```

**Database imefuta data**
```bash
# Database iko: backend/referral.db
# Backup mara kwa mara!
cp referral.db referral.db.backup
```
